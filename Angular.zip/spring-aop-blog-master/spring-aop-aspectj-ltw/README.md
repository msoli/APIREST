# spring-aop-aspectj-ltw

Demonstrates how to set up real AspectJ loadtime weaving in Spring Boot.

**Requires both of the following JVM arguments to run** 
_(insert your own paths to these JARs, which are provided in this folder):_

* -javaagent:path/to/spring-aop-aspectj-ltw/spring-instrument-4.2.5.RELEASE.jar
* -javaagent:path/to/spring-aop-aspectj-ltw/aspectjweaver-1.8.8.jar
