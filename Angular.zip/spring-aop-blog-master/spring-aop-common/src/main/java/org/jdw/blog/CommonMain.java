package org.jdw.blog;

public class CommonMain {
    public static void main(String[] args) {
        // Placeholder for Gradle startScripts task

        // This project is meant to be included as a library,
        // and is not intended to run as a standalone application.
    }
}
