# spring-aop-proxy

Demonstrates default JDK proxy based Spring AOP.
