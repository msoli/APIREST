# spring-aop-proxy-cglib

Demonstrates Spring AOP using CGLIB.
