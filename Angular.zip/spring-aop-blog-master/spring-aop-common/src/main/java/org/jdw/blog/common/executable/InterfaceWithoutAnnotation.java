package org.jdw.blog.common.executable;

public interface InterfaceWithoutAnnotation {

    public long hystrixWrappedGetCurrentThreadId();

    public long nestedHystrixWrappedGetCurrentThreadId();

}