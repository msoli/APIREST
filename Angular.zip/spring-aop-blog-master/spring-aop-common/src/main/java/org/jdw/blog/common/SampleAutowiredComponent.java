package org.jdw.blog.common;

import org.springframework.stereotype.Component;

/**
 * Only present to prove a Spring bean can be autowired into an aspect.
 */
@Component
public class SampleAutowiredComponent {

}
