package com.mikeio.config;

/**
 * Created by SISTEMAS03-PC on 20/01/2017.
 */
public class MikeIoProperties {
}
