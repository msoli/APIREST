package org.jdw.blog;

import org.junit.Test;

public class ApplicationContextTest extends BaseSpringJUnitTest {

    @Test
    public void contextLoads() {
    }

}
